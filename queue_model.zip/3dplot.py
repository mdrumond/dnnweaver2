'''
Created on 1 Apr 2019

@author: ACY
'''

#%% # noqa: E265
import numpy as np
import sys


def in_ipynb():
    if 'ipykernel' in sys.modules or 'IPython' in sys.modules:
        return True
    else:
        return False


if not in_ipynb():
    print("Using TkAgg")
    import matplotlib
    matplotlib.use("TkAgg")

from mpl_toolkits.mplot3d import Axes3D  # noqa: F401,E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import EngFormatter  # noqa: E402

#%% # noqa: E265
sram_bytes_per_area = 960e3
sram_joules_per_bytes = 1.3e-12

alu_op_per_area = 2.5e3
alu_joules_per_op = 200e-15

area_envelope, power_envelope, frequency = 300, 75, 1e9

#%% # noqa: E265
def gen_graph():

    widths = np.array(range(1, 51000, 50))
    lengths = np.array(range(1, 101))

    lengths, widths = np.meshgrid(lengths, widths)

    capacity = (area_envelope - widths*lengths/alu_op_per_area) * sram_bytes_per_area
    capacity_mask = capacity < 0
    capacity[capacity_mask] = np.nan
    capacity_masked = np.ma.masked_where(capacity == 0, capacity)

    power = (widths*lengths*alu_joules_per_op*frequency + widths*sram_joules_per_bytes*frequency + 2*lengths*sram_joules_per_bytes*frequency)
    power_mask = power > power_envelope
    power[power_mask] = np.nan
    power_masked = np.ma.masked_where(power == 0, power)
    # power_masked = power

    throughput = widths*lengths*frequency
    throughput[capacity_mask] = np.nan
    throughput[power_mask] = np.nan
    throughput_masked = np.ma.masked_where(throughput == 0, throughput)
    # throughput_masked = throughput
    return widths, lengths, capacity_masked, power_masked, throughput_masked

#%% # noqa: E265
def plot_contour_graph(name, x, y, z, levels, zlims):
    fig, ax = plt.subplots()

    CS = ax.contour(x, y, z, cmap='Dark2', levels=levels)

    fmt = EngFormatter()
    fmt.create_dummy_axis()
    plt.clabel(CS, fontsize=15, inline=1, fmt=fmt, use_clabeltext=True)
    ax.set_xlabel('Array Width', fontsize=15)
    ax.set_ylabel('Array Length', fontsize=15)
    # cmap=cm.coolwarm, vmin=zlims[0], vmax=zlims[1], linewidth=0,
    # antialiased=False
    # if zlims is not None:
    #     ax.set_zlim(*zlims)
    #     ax.zaxis.set_major_locator(LinearLocator(10))
    #     # ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))
    # ax.view_init(30, 90)
    plt.tight_layout()
    fig.show()
    if not in_ipynb():
        fig.savefig(name)

#%% # noqa: E265
def plot_3d_graph(name, x, y, z, levels, zlims, z_title):
    fig = plt.figure()
    ax = fig.gca(projection='3d')

    ax.plot_surface(x, y, z, rstride=1, cstride=1,
                    cmap='viridis', vmin=zlims[0], vmax=zlims[1],
                    edgecolor='none')

    ax.set_xlabel('Array Width', fontsize=15)
    ax.set_ylabel('Array Length', fontsize=15)
    ax.set_zlabel(z_title, fontsize=15)
    ax.zaxis.set_major_formatter(EngFormatter())
    ax.view_init(30, 225)
    plt.tight_layout()
    #plt.show()
    
    for angle in range(0, 360):
        ax.view_init(30, angle)
        plt.draw()
        plt.pause(.001)
    
    if not in_ipynb():
        fig.savefig(name)




widths, lengths, capacity, power, throughput = gen_graph()

#plot_contour_graph('capacity_contour.pdf', widths, lengths, capacity,[4.0e+07, 1.6e+08, 2.4e+08], [0, 512e6])
#plot_contour_graph('power_contour.pdf', widths, lengths, power, [25, 50, 74],[0, power_envelope])
#plot_contour_graph('throughput_contour.pdf', widths, lengths, throughput,[1.0e+14, 2.5e+14, 3e+14], [0, 400e12])

plot_3d_graph('capacity_3d.pdf', widths, lengths, capacity, [4.0e+07, 1.6e+08, 2.4e+08], [0, 512e6], 'Capacity')
#plot_3d_graph('power_3d.pdf', widths, lengths, power, [25, 50, 74], [0, power_envelope], 'Power')
#plot_3d_graph('throughput_3d.pdf', widths, lengths, throughput, [1.0e+14, 2.5e+14, 3e+14], [0, 400e12], 'Throughput')





