import pickle
import numpy as np
#from nn import nn
import matplotlib.pyplot as plt

import matplotlib as mpl
mpl.use('pdf')

colors = ['firebrick', 'darkgreen', 'navy', 'darkorange', 'purple', 'turquoise']
linestyles = ['-', '--', '-.', ':']
markers = ['o', 'v', 's', '*']

def set_options(plt):
    font_size = 10
    plt.rc('font', family='serif')
    plt.rc('text', usetex=True)
    plt.rc('xtick', labelsize=font_size)
    plt.rc('ytick', labelsize=font_size)
    plt.rc('axes', labelsize=font_size)
    
    # width as measured in inkscape
    width = 3.487
    height = width / 1.618
    
    fig = plt.gcf()
    ax = plt.gca()
    
    fig.subplots_adjust(left=.18, bottom=.20, right=.99, top=.97)
    fig.set_size_inches(width, height)
    
def academic_plot(plt, plt_ind, x=None, y=None, linestyle=None, linewidth=2, marker=None, xlabel=None, ylabel=None, xlim=None, ylim=None, legend_label=None):
    assert y is not None
    
    set_options(plt)
    fig = plt.gcf()
    ax = plt.gca()
    
    if marker is not None:
        marker = markers[plt_ind%len(markers)]
    
    if linestyle is not None:
        linestyle = linestyles[plt_ind%len(linestyles)]
    
    color = colors[plt_ind%len(colors)]
    
    if x is not None:
        plt.plot(x, y, label=legend_label, linewidth=linewidth, marker=marker, linestyle=linestyle, color=color)
    else:
        plt.plot(y,label=legend_label)
    
    ax.legend()
    
    if ylabel is not None:
        ax.set_ylabel(ylabel)
    if xlabel is not None:
        ax.set_xlabel(xlabel)
    if xlim is not None:
        ax.set_xlim(xlim[0], xlim[1])
    if ylim is not None:
        ax.set_ylim(ylim[0], ylim[1])     
        
    
    
def save_figure(plt, name='plot'):
    fig = plt.gcf()
    fig.savefig(name+'.pdf')
    
    
    
    
    
# if __name__ == '__main__':
#     [x_tr,y_tr,x_val,y_val,x_test,y_test] = pickle.load( open( "iris_dataset.p", "rb" ) )
#     
#     layer_dims = [4,20,3]
#     learning_rate = 0.0002
#     
#     nn1 = nn(layer_dims, learning_rate, decay_rate=1.0, decay_steps=10, momentum_coef=0.9)
# 
#     iz = np.arange(-50e-6,150e-6,1e-6) / 50e-6
#     vz = np.arange(0,1.8,0.05)
#     xv, yv, zv = np.meshgrid(iz, vz, np.arange(0,18))
#     query = np.concatenate([xv.reshape(-1,1),yv.reshape(-1,1),zv.reshape(-1,1)],axis=1)    
#     
#     y = nn1.circuit.is_interp.eval(query)
#     y = y.reshape(36,200,18)
#     for i in range(18):
#         academic_plot(plt, plt_ind=i, x=iz*50, y=y[18,:,i]*50, xlabel='Iz (uA)', ylabel='Is (uA)')
#         #plt.title()
#     save_figure(plt, name='synapse_char')
#     plt.show()

