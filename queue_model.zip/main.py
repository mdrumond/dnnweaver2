'''
Created on 26 Mar 2019

@author: ACY
'''


import numpy as np
import matplotlib.pyplot as plt
import pickle
#from academic_plotter import set_options

np.random.seed(1)

sram_bytes_per_area = 960e3
sram_joules_per_bytes = 1.3e-12

alu_op_per_area = 2.5e3
alu_joules_per_op = 200e-15

area_envelope, power_envelope, frequency = 300., 75., 1e9

avg_layer_ops = 20e6

Tslo = 0.1e-3

def queue_model(lengths, widths, Tsim, load_perc):
    load = lengths * widths * frequency * Tsim * load_perc
    no_req = load / avg_layer_ops

    layer_exec_time = avg_layer_ops / widths / frequency
    arrival_rate = no_req / Tsim
    avg_arrival_time = 1. / arrival_rate
    Tstep = 0.05e-6
    noSteps = int(Tsim / Tstep)
    arrive_prob = arrival_rate*Tstep
    layer_exec_cycle = int(layer_exec_time/Tstep)
    print('#request:{} Avg.arrivaltime:{}s Simsteptime:{}s #TimeSteps:{} Arriveprob:{} ExecTime:{}s ExecCycles:{}'.format(no_req, avg_arrival_time, Tstep, noSteps, arrive_prob,layer_exec_time,layer_exec_cycle))
    
    arrive = np.random.uniform(size=int(noSteps))<arrive_prob
    no_arrivals = np.sum(arrive)
    retire_steps = np.zeros(shape=(no_arrivals))
    
    start_exec_time = np.argwhere(arrive==True).squeeze() + int(Tslo / Tstep) - layer_exec_cycle
    
    q_cnt = 0
    q_head_ind = 0
    no_burst = 0
    batch_cnt = 0
    pe_busy = False
    for t in range(noSteps):
        if arrive[t]==True:
            q_cnt += 1
        
        if q_head_ind < no_arrivals:
            if q_cnt >= lengths:
                if pe_busy==False:
                    pe_busy=True
                    exec_cycle = 0
                    eff_batch = lengths
                    q_cnt -= lengths
                    q_head_ind += lengths
                    no_burst += 1
                    batch_cnt += lengths
            elif t == start_exec_time[q_head_ind]:
                if pe_busy==False:
                    pe_busy=True
                    exec_cycle = 0
                    eff_batch = q_cnt
                    q_head_ind += q_cnt
                    q_cnt = 0
                    no_burst += 1
                    batch_cnt += q_cnt
        
#         if q_head_ind < no_arrivals:
#             if t > start_exec_time[q_head_ind]:
#                 return None, None, None
        
        
        if pe_busy==True:
            if exec_cycle <= layer_exec_cycle: 
                exec_cycle += 1
            else:
                retire_steps[q_head_ind-eff_batch:q_head_ind]=t
                pe_busy = False
  
    arrive_steps = np.argwhere(arrive==True).squeeze()
    
    latencies = (retire_steps - arrive_steps)*Tstep
    #plt.hist(latencies*1e6)
    #plt.show()
        
    max_latency = np.max(latencies*1e3)
    eff_batch_size = float(batch_cnt) / no_burst
    return max_latency, eff_batch_size, no_burst





if __name__ == '__main__':
#     ax1 = plt.gca()
#     ax1.set_xlabel('Load (%)')
#     ax1.set_ylabel('Throughput (TOP/s)')
#        
#     [avail_throughput_list, max_latency_list, throughput_list, effective_throughput_list, load_list, lengths_list] = pickle.load(open( "slo_100us.p", "rb" ))
#     for i in range(effective_throughput_list.shape[0]):
#         for j in range(effective_throughput_list.shape[1]):   
#             if max_latency_list[i,j] > Tslo*1e3+0.001:
#                 effective_throughput_list[i,j] = np.nan
#                 avail_throughput_list[i,j] = np.nan
#        
#     slo_line = Tslo*1e3 + np.zeros(shape=(effective_throughput_list.shape[0]))
#           
#     colors = ['tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:cyan','tab:brown', 'tab:pink', 'tab:gray', 'tab:olive']    
#     for b in range(len(lengths_list)):
#         plt.figure(1) 
#         plt.plot(np.array(load_list)*100, avail_throughput_list[:,b]*1e-12, '-o', label='Batch size:' + str(lengths_list[b]), color=colors[b])
#         plt.figure(2) 
#         plt.plot(np.array(load_list)*100, max_latency_list[:,b], '-o', label='Batch size:' + str(lengths_list[b]), color=colors[b])
#         #plt.show()
#     plt.plot(np.array(load_list)*100, slo_line, '--', label='SLO', color=colors[b+2])
#           
#     plt.figure(1)
#     ax1 = plt.gca()
#     ax1.set_xlabel('Load (%)')
#     ax1.set_ylabel('Available Throughput for Training (TOP/s)')
#     ax1.set_ylim(0, np.max(throughput_list)*1e-12*1.1)
#     ax1.set_xlim(0, 100)
#     #chartBox = ax1.get_position()
#     #ax1.set_position([chartBox.x0, chartBox.y0, chartBox.width*0.6, chartBox.height])
#     ax1.legend(loc='upper center', bbox_to_anchor=(1.45, 0.8), shadow=True, ncol=1)
#     plt.legend()
# 
#     plt.figure(2)
#     ax1 = plt.gca()
#     ax1.set_xlabel('Load (%)')
#     ax1.set_ylabel('Latency (ms)')
#     ax1.set_ylim(0, Tslo*1e3*1.1)
#     ax1.set_xlim(0, 100)
#     ax1.legend(loc='upper center', bbox_to_anchor=(1.45, 0.8), shadow=True, ncol=1)
#     plt.legend()    
# 
#     plt.figure(1)
#     fig = plt.gcf()
#     fig.savefig('train_truput_vs_load.pdf')
#         
#     plt.figure(2)    
#     fig = plt.gcf()
#     fig.savefig('latency_vs_load.pdf')
#     
#     plt.show()       
#     
#     exit()

    #load_list = [0.05, 0.1, 0.2, 0.4, 0.6, 0.8, 0.95]
    #load_list = [0.001, 0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.1, 0.2, 0.4, 0.6, 0.8, 0.85, 0.875, 0.9,0.91,0.92,0.93,0.94,0.95,0.96,0.97,0.98,0.99,0.991,0.992,0.993,0.994,0.995,0.996,0.997,0.998,0.999]
    load_list = np.arange(0.05, 1.001, 0.05)
    load_list[-1] = 0.999
    
    lengths_list = [1,8,64,512]
    #lengths_list = [256]
    max_latency_list = np.zeros((len(load_list), len(lengths_list)))
    throughput_list = np.zeros((len(load_list), len(lengths_list)))
    effective_throughput_list = np.zeros((len(load_list), len(lengths_list)))
    avail_throughput_list = np.zeros((len(load_list), len(lengths_list)))
    for i in range(len(load_list)):  
        load_perc = load_list[i]
        #lengths_list = np.arange(60,250,20)
        
        batch_efficiency = []
        for j in range(len(lengths_list)):
            lengths = lengths_list[j]
            widths = np.floor( (power_envelope - 2*lengths*sram_joules_per_bytes*frequency) / (lengths*alu_joules_per_op*frequency + sram_joules_per_bytes*frequency))
            print('Load %: {}, L:{} W:{}'.format(load_perc, lengths, widths))
            
            capacity = ((area_envelope - (widths*lengths)/alu_op_per_area) *sram_bytes_per_area)
            power = ((widths*lengths*alu_joules_per_op*frequency) + widths*sram_joules_per_bytes*frequency)
            throughput = widths*lengths*frequency
            area = widths*lengths/alu_op_per_area + capacity/sram_bytes_per_area
            print('Area:{} BRAM Capacity: {} MB, Total Power: {} W, Throughput: {} TOPs'.format(area, capacity/1024/1024, power, throughput/1e12))
            
            Tsim = 0.1
            #eff_batch_size = queue_model(lengths, widths, Tsim, load_perc)
            max_latency, eff_batch_size, no_burst = queue_model(lengths, widths, Tsim, load_perc)
            max_latency_list[i,j] = max_latency
            
            if max_latency is None:
                print("SLO VIOLATED!!!!!!!!!!!")
                continue
            
            batch_eff = eff_batch_size/lengths
            layer_exec_time = avg_layer_ops / widths / frequency

            Tbusy = no_burst*layer_exec_time
            if Tbusy>Tsim:
                print("WARNING!!! Tsim:{} Tbusy:{} load:{} batch:{}".format(Tsim, Tbusy, load_perc, lengths))
            Tidle = np.maximum(Tsim - Tbusy,0)
            
            avail_throughput = (Tidle*throughput + Tbusy*throughput*(1-batch_eff)) / Tsim
            
            
            
            effective_throughput = (Tidle*throughput + Tbusy*throughput*batch_eff) / Tsim
            effective_throughput_list[i,j] = effective_throughput
            avail_throughput_list[i,j] = avail_throughput
            throughput_list[i,j] = throughput
            
            print('Max latency:{}ms Batch efficiency: {} Throughput: {} TOPs Effective Throughput: {} TOPs'.format(max_latency, batch_eff, throughput/1e12, effective_throughput/1e12)) 
            batch_efficiency.append(100*batch_eff)   
    
    
    #plt.plot(load_list, max_latency_list)
    #plt.show()
    
    pickle.dump( [avail_throughput_list, max_latency_list, throughput_list, effective_throughput_list, load_list, lengths_list] , open( "slo_100us.p", "wb" ) )

    
    
    
